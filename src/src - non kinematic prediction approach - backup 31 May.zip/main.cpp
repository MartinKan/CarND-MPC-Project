#include <math.h>
#include <uWS/uWS.h>
#include <chrono>
#include <iostream>
#include <thread>
#include <vector>
#include "Eigen-3.3/Eigen/Core"
#include "Eigen-3.3/Eigen/QR"
#include "MPC.h"
#include "json.hpp"

// for convenience
using json = nlohmann::json;

// For converting back and forth between radians and degrees.
constexpr double pi() { return M_PI; }
double deg2rad(double x) { return x * pi() / 180; }
double rad2deg(double x) { return x * 180 / pi(); }

// Checks if the SocketIO event has JSON data.
// If there is data the JSON object in string format will be returned,
// else the empty string "" will be returned.
string hasData(string s) {
  auto found_null = s.find("null");
  auto b1 = s.find_first_of("[");
  auto b2 = s.rfind("}]");
  if (found_null != string::npos) {
    return "";
  } else if (b1 != string::npos && b2 != string::npos) {
    return s.substr(b1, b2 - b1 + 2);
  }
  return "";
}

// Evaluate a polynomial.
double polyeval(Eigen::VectorXd coeffs, double x) {
  double result = 0.0;
  for (int i = 0; i < coeffs.size(); i++) {
    result += coeffs[i] * pow(x, i);
  }
  return result;
}

// Fit a polynomial.
// Adapted from
// https://github.com/JuliaMath/Polynomials.jl/blob/master/src/Polynomials.jl#L676-L716
Eigen::VectorXd polyfit(Eigen::VectorXd xvals, Eigen::VectorXd yvals,
                        int order) {
  assert(xvals.size() == yvals.size());
  assert(order >= 1 && order <= xvals.size() - 1);
  Eigen::MatrixXd A(xvals.size(), order + 1);

  for (int i = 0; i < xvals.size(); i++) {
    A(i, 0) = 1.0;
  }

  for (int j = 0; j < xvals.size(); j++) {
    for (int i = 0; i < order; i++) {
      A(j, i + 1) = A(j, i) * xvals(j);
    }
  }

  auto Q = A.householderQr();
  auto result = Q.solve(yvals);
  return result;
}

int main(int argc, char** argv) {
  uWS::Hub h;

  // MPC is initialized here!
  MPC mpc(argv);


  h.onMessage([&mpc](uWS::WebSocket<uWS::SERVER> ws, char *data, size_t length,
                     uWS::OpCode opCode) {
    // "42" at the start of the message means there's a websocket message event.
    // The 4 signifies a websocket message
    // The 2 signifies a websocket event
    string sdata = string(data).substr(0, length);
    cout << sdata << endl;
    if (sdata.size() > 2 && sdata[0] == '4' && sdata[1] == '2') {
      string s = hasData(sdata);
      if (s != "") {
        auto j = json::parse(s);
        string event = j[0].get<string>();
        if (event == "telemetry") {
          // j[1] is the data JSON object
          vector<double> ptsx = j[1]["ptsx"];
          vector<double> ptsy = j[1]["ptsy"];
          double px = j[1]["x"];
          double py = j[1]["y"];
          double psi = j[1]["psi"];
          double v = j[1]["speed"];

          // transform the waypoint coordinates from map space to car space (origin will be the car's location)
          vector<double> ptsx_transformed;
          vector<double> ptsy_transformed;
          for (int i = 0; i < ptsx.size(); i++)
          {
          	double x = ptsx[i] - px;
		  	double y = ptsy[i] - py;
          	double x_transformed = x * cos(-psi) - y * sin(-psi);
          	double y_transformed = x * sin(-psi) + y * cos(-psi);
          	ptsx_transformed.push_back(x_transformed);
          	ptsy_transformed.push_back(y_transformed);
          }

		  // Fit a polynomial to the waypoint coordinates
		  Eigen::VectorXd ptsx_temp = Eigen::Map<Eigen::VectorXd, Eigen::Unaligned>(ptsx_transformed.data(), ptsx_transformed.size());
  		  Eigen::VectorXd ptsy_temp = Eigen::Map<Eigen::VectorXd, Eigen::Unaligned>(ptsy_transformed.data(), ptsy_transformed.size());
		  auto coeffs = polyfit(ptsx_temp, ptsy_temp, 3);

		  // Calculate the cross track error
		  // double cte = polyeval(coeffs, 0); //the polynomial is computed relative to the car's location, which is (0,0)
		  double cte = coeffs[0];
		  // Calculate the orientation error
		  double epsi = -atan(coeffs[1]); // psi is 0 and can be omitted

		  Eigen::VectorXd state(6);
		  state << 0.0, 0.0, 0.0, v, cte, epsi;

		  std::vector<double> x_vals = {state[0]};
		  std::vector<double> y_vals = {state[1]};
		  std::vector<double> psi_vals = {state[2]};
		  std::vector<double> v_vals = {state[3]};
		  std::vector<double> cte_vals = {state[4]};
		  std::vector<double> epsi_vals = {state[5]};
		  std::vector<double> delta_vals = {};
		  std::vector<double> a_vals = {};

		  auto vars = mpc.Solve(state, coeffs);

		  x_vals.erase(x_vals.begin());
		  y_vals.erase(y_vals.begin());
		  x_vals.push_back(vars[0]);
		  y_vals.push_back(vars[1]);
		  psi_vals.push_back(vars[2]);
		  v_vals.push_back(vars[3]);
		  cte_vals.push_back(vars[4]);
		  epsi_vals.push_back(vars[5]);
		  delta_vals.push_back(vars[6]);
		  a_vals.push_back(vars[7]);

		  for (int i = 8; i < (8 + ((vars.size() - 8) / 2)); i++) {
    	  		x_vals.push_back(vars[i]);
  		  }

  		  for (int i = (8 + ((vars.size() - 8) / 2)); i < vars.size(); i++) {
    	  		y_vals.push_back(vars[i]);
  		  }

          /*
          * TODO: Calculate steering angle and throttle using MPC.
          *
          * Both are in between [-1, 1].
          *
          */
          double steer_value = delta_vals[0];
          double throttle_value = a_vals[0];

          json msgJson;
          // NOTE: Remember to divide by deg2rad(25) before you send the steering value back.
          // Otherwise the values will be in between [-deg2rad(25), deg2rad(25] instead of [-1, 1].
          msgJson["steering_angle"] = steer_value;
          msgJson["throttle"] = throttle_value;

          //Display the MPC predicted trajectory 
          vector<double> mpc_x_vals;
          vector<double> mpc_y_vals;

          mpc_x_vals = x_vals;
          mpc_y_vals = y_vals;

          //.. add (x,y) points to list here, points are in reference to the vehicle's coordinate system
          // the points in the simulator are connected by a Green line

          msgJson["mpc_x"] = mpc_x_vals;
          msgJson["mpc_y"] = mpc_y_vals;

          //Display the waypoints/reference line
          vector<double> next_x_vals;
          vector<double> next_y_vals;

          next_x_vals = ptsx_transformed;
          next_y_vals = ptsy_transformed;

          //.. add (x,y) points to list here, points are in reference to the vehicle's coordinate system
          // the points in the simulator are connected by a Yellow line

          msgJson["next_x"] = next_x_vals;
          msgJson["next_y"] = next_y_vals;


          auto msg = "42[\"steer\"," + msgJson.dump() + "]";
          // std::cout << msg << std::endl;
          //std::cout << "dt: " << argv[2] << std::endl;
          // std::cout << "psi: " << psi << std::endl;
          // std::cout << "epsi: " << epsi << std::endl;
          // std::cout << "x vals size: " << x_vals.size() << std::endl;
          // std::cout << "y vals size: " << y_vals.size() << std::endl;
          // // std::cout << "x vals 0: " << x_vals[0] << std::endl;
          // // std::cout << "x vals 1: " << x_vals[1] << std::endl;
          // // std::cout << "x vals 2: " << x_vals[2] << std::endl;
          // std::cout << "y vals size: " << y_vals.size() << std::endl;
          
          // Latency
          // The purpose is to mimic real driving conditions where
          // the car does actuate the commands instantly.
          //
          // Feel free to play around with this value but should be to drive
          // around the track with 100ms latency.
          //
          // NOTE: REMEMBER TO SET THIS TO 100 MILLISECONDS BEFORE
          // SUBMITTING.
          this_thread::sleep_for(chrono::milliseconds(100));
          ws.send(msg.data(), msg.length(), uWS::OpCode::TEXT);
        }
      } else {
        // Manual driving
        std::string msg = "42[\"manual\",{}]";
        ws.send(msg.data(), msg.length(), uWS::OpCode::TEXT);
      }
    }
  });

  // We don't need this since we're not using HTTP but if it's removed the
  // program
  // doesn't compile :-(
  h.onHttpRequest([](uWS::HttpResponse *res, uWS::HttpRequest req, char *data,
                     size_t, size_t) {
    const std::string s = "<h1>Hello world!</h1>";
    if (req.getUrl().valueLength == 1) {
      res->end(s.data(), s.length());
    } else {
      // i guess this should be done more gracefully?
      res->end(nullptr, 0);
    }
  });

  h.onConnection([&h](uWS::WebSocket<uWS::SERVER> ws, uWS::HttpRequest req) {
    std::cout << "Connected!!!" << std::endl;
  });

  h.onDisconnection([&h](uWS::WebSocket<uWS::SERVER> ws, int code,
                         char *message, size_t length) {
    ws.close();
    std::cout << "Disconnected" << std::endl;
  });

  int port = 4567;
  if (h.listen(port)) {
    std::cout << "Listening to port " << port << std::endl;
  } else {
    std::cerr << "Failed to listen to port" << std::endl;
    return -1;
  }
  h.run();
}
